var searchData=
[
  ['saisie',['Saisie',['../ex01_8c.html#a95bdb8cd2edecca19a4de8c6a75e4361',1,'ex01.c']]],
  ['saisieentier',['saisieEntier',['../ex01_8c.html#a357a8e2dfd40c3f9503ec9768377d89f',1,'ex01.c']]]
];
