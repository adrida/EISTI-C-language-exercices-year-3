var indexSectionsWithContent =
{
  0: "em",
  1: "e",
  2: "em"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions"
};

