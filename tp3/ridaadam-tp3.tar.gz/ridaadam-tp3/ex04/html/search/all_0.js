var searchData=
[
  ['affichagetriangle',['affichageTriangle',['../ex04_8c.html#a2363b07f27acb7b910b56142087ef15b',1,'ex04.c']]]
];
