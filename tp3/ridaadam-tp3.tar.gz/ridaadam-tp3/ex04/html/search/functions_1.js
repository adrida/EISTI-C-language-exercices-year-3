var searchData=
[
  ['estamstrong',['estAmstrong',['../ex04_8c.html#adeac44f5233628217815596bf010e512',1,'ex04.c']]]
];
